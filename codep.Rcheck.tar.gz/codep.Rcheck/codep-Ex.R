pkgname <- "codep"
source(file.path(R.home("share"), "R", "examples-header.R"))
options(warn = 1)
base::assign(".ExTimings", "codep-Ex.timings", pos = 'CheckExEnv')
base::cat("name\tuser\tsystem\telapsed\n", file=base::get(".ExTimings", pos = 'CheckExEnv'))
base::assign(".format_ptime",
function(x) {
  if(!is.na(x[4L])) x[1L] <- x[1L] + x[4L]
  if(!is.na(x[5L])) x[2L] <- x[2L] + x[5L]
  options(OutDec = '.')
  format(x[1L:3L], digits = 7L)
},
pos = 'CheckExEnv')

### * </HEADER>
library('codep')

base::assign(".oldSearch", base::search(), pos = 'CheckExEnv')
base::assign(".old_wd", base::getwd(), pos = 'CheckExEnv')
cleanEx()
nameEx("Doubs")
### * Doubs

flush(stderr()); flush(stdout())

base::assign(".ptime", proc.time(), pos = "CheckExEnv")
### Name: Doubs
### Title: The Doubs Fish Data
### Aliases: Doubs Doubs.fish Doubs.env Doubs.geo
### Keywords: Doubs

### ** Examples

data(Doubs)
summary(Doubs.fish)
summary(Doubs.env)
summary(Doubs.geo)




base::assign(".dptime", (proc.time() - get(".ptime", pos = "CheckExEnv")), pos = "CheckExEnv")
base::cat("Doubs", base::get(".format_ptime", pos = 'CheckExEnv')(get(".dptime", pos = "CheckExEnv")), "\n", file=base::get(".ExTimings", pos = 'CheckExEnv'), append=TRUE, sep="\t")
cleanEx()
nameEx("Euclid")
### * Euclid

flush(stderr()); flush(stdout())

base::assign(".ptime", proc.time(), pos = "CheckExEnv")
### Name: Euclid
### Title: Calculation of the Euclidean Distance
### Aliases: Euclid

### ** Examples

## A set of reference points:
x <- cbind(c(1,4,5,2,8,4), c(3,6,7,1,3,2))
dimnames(x) <- list(LETTERS[1:6], c("x", "y"))

## The pairwise Euclidean distances among the reference points: 
d1 <- Euclid(x)
d1

## That result is the same as that obtained from function dist:
d2 <- dist(x, method = "euclidean")
all(d1 == d2)

## A second set of points:
y <- cbind(c(3,5,7), c(3,6,8))
dimnames(y) <- list(LETTERS[7:9], c("x", "y"))

## The distances between the points in y (rows) and x (columns):
Euclid(x, y)




base::assign(".dptime", (proc.time() - get(".ptime", pos = "CheckExEnv")), pos = "CheckExEnv")
base::cat("Euclid", base::get(".format_ptime", pos = 'CheckExEnv')(get(".dptime", pos = "CheckExEnv")), "\n", file=base::get(".ExTimings", pos = 'CheckExEnv'), append=TRUE, sep="\t")
cleanEx()
nameEx("codep-package")
### * codep-package

flush(stderr()); flush(stdout())

base::assign(".ptime", proc.time(), pos = "CheckExEnv")
### Name: codep-package
### Title: Multiscale Codependence Analysis
### Aliases: codep-package

### ** Examples

data(mite)
emap <- eigenmap(x=mite.geo, weighting=wf.RBF, wpar=0.1)
emap

## Organize the environmental variables
mca0 <- MCA(Y = log1p(mite.species), X=mite.env, emobj=emap)
mca0_partest <- test.cdp(mca0, response.tests=FALSE)
summary(mca0_partest)
plot(mca0_partest, las=2, lwd=2)
plot(mca0_partest, col=rainbow(1200)[1L:1000], las=3, lwd=4,
     main="Codependence diagram", col.signif="white")

rng <- list(x=seq(min(mite.geo[,"x"]) - 0.1, max(mite.geo[,"x"]) + 0.1, 0.05),
            y=seq(min(mite.geo[,"y"]) - 0.1, max(mite.geo[,"y"]) + 0.1, 0.05))
grid <- cbind(x=rep(rng[["x"]], length(rng[["y"]])),
              y=rep(rng[["y"]], each=length(rng[["x"]])))
newdists <- matrix(NA, nrow(grid), nrow(mite.geo))
for(i in 1L:nrow(grid)) {
  newdists[i,] <- ((mite.geo[,"x"] - grid[i,"x"])^2 +
                     (mite.geo[,"y"] - grid[i,"y"])^2)^0.5
}

spmeans <- colMeans(mite.species)
pca0 <- svd(log1p(mite.species) - rep(spmeans, each=nrow(mite.species)))

prd0 <- predict(
  mca0_partest,
  newdata=list(target=eigenmap.score(emap, newdists))
)
Uprd0 <- (prd0 - rep(spmeans, each=nrow(prd0))) %*% pca0$v %*%
  diag(pca0$d^-1)

## Printing the response variable
prmat <- Uprd0[,1L]
dim(prmat) <- c(length(rng$x),length(rng$y))
zlim <- c(min(min(prmat),min(pca0$u[,1L])),max(max(prmat),max(pca0$u[,1L])))
image(z=prmat, x=rng$x, y=rng$y, asp=1, zlim=zlim,
      col=rainbow(1200L)[1L:1000], ylab="y", xlab="x")
points(
  x=mite.geo[,"x"], y=mite.geo[,"y"], pch=21,
  bg=rainbow(1200L)[round(1+(999*(pca0$u[,1L]-zlim[1L])/
                    (zlim[2L]-zlim[1L])),0)]
)





base::assign(".dptime", (proc.time() - get(".ptime", pos = "CheckExEnv")), pos = "CheckExEnv")
base::cat("codep-package", base::get(".format_ptime", pos = 'CheckExEnv')(get(".dptime", pos = "CheckExEnv")), "\n", file=base::get(".ExTimings", pos = 'CheckExEnv'), append=TRUE, sep="\t")
cleanEx()
nameEx("cthreshold")
### * cthreshold

flush(stderr()); flush(stdout())

base::assign(".ptime", proc.time(), pos = "CheckExEnv")
### Name: cthreshold
### Title: Familywise Type I Error Rate
### Aliases: cthreshold

### ** Examples

## For a familywise threshold of 5% with 5 tests:
cthreshold(0.05, 5)   ## The corrected threshold for each test is 0.01020622




base::assign(".dptime", (proc.time() - get(".ptime", pos = "CheckExEnv")), pos = "CheckExEnv")
base::cat("cthreshold", base::get(".format_ptime", pos = 'CheckExEnv')(get(".dptime", pos = "CheckExEnv")), "\n", file=base::get(".ExTimings", pos = 'CheckExEnv'), append=TRUE, sep="\t")
cleanEx()
nameEx("eigenmap")
### * eigenmap

flush(stderr()); flush(stdout())

base::assign(".ptime", proc.time(), pos = "CheckExEnv")
### Name: eigenmap
### Title: Spatial Eigenvector Maps
### Aliases: eigenmap eigenmap.score

### ** Examples

### Example 1: A linear transect.
data(salmon)

## No boundaries provided for a function that requires them: a warning is
## issued
map <- eigenmap(x=salmon[,"Position"], weighting=wf.binary)
map
## plot(map)

## The function issues no warning when boundaries are provided
map <- eigenmap(x=salmon[,"Position"], weighting=wf.binary,
                boundaries=c(0,20))
map
## plot(map)

map <- eigenmap(x=salmon[,"Position"], weighting=wf.Drayf1,
                boundaries=c(0,20))
map
## plot(map)

map <- eigenmap(x=salmon[,"Position"], weighting=wf.Drayf2,
                boundaries=c(0,20))
map
## plot(map)

map <- eigenmap(x=salmon[,"Position"], weighting=wf.Drayf3,
                boundaries=c(0,20), wpar=2)
map
## plot(map)

map <- eigenmap(x=salmon[,"Position"], weighting=wf.PCNM, boundaries=c(0,20))
map
## plot(map)

map <- eigenmap(x=salmon[,"Position"], weighting=wf.sqrd)
map
## plot(map)

map <- eigenmap(x=salmon[,"Position"], weighting=wf.RBF, wpar=0.001)
map
## plot(map)

### Example 2: Using predictor scores

smpl <- c(4,7,10,14,34,56,61,64)  # A sample to be discarded
map <- eigenmap(x=salmon[-smpl,"Position"], weighting=wf.sqrd)
scr <- eigenmap.score(
         map, target=as.matrix(dist(salmon[,"Position"]))[,-smpl]
       )
## Scores of sampling points are the eigenvectors
scr[smpl,]

wh <- 5L   # You can try with other vectors.
plot(map$U[,wh]~salmon[-smpl,"Position"], ylab=expression(U[5]),
     xlab="Position along transect")
points(y=scr[smpl,wh], x=salmon[smpl,"Position"], pch=21L, bg="black")

map <- eigenmap(x=salmon[-smpl,"Position"], weighting=wf.binary,
                boundaries=c(0,20))
scr <- eigenmap.score(
         map, target=as.matrix(dist(salmon[,"Position"]))[smpl,-smpl]
       )

wh <- 1L   # One could try the other vectors.
plot(map$U[,wh]~salmon[-smpl,"Position"], ylab = expression(U[1L]),
     xlab = "Position along transect (m)")
points(y=scr[,wh], x=salmon[smpl,"Position"], pch=21L, bg="black")

map <- eigenmap(x=salmon[-smpl,"Position"], weighting=wf.PCNM,
                boundaries=c(0,100))
scr <- eigenmap.score(
         map, target=as.matrix(dist(salmon[,"Position"]))[smpl,-smpl]
       )

wh <- 1L   # You can try with other vectors.
plot(map$U[,wh]~salmon[-smpl,"Position"], ylab = expression(U[1]),
     xlab = "Position along transect (m)")
points(y=scr[,wh], x=salmon[smpl,"Position"], pch=21L, bg="black")

### Example 3: A unevenly sampled surface.

data(mite)
map <- eigenmap(x=as.matrix(mite.geo), weighting=wf.sqrd)
map
## plot(map)

map <- eigenmap(x=as.matrix(mite.geo), weighting=wf.RBF)
map
## plot(map)





base::assign(".dptime", (proc.time() - get(".ptime", pos = "CheckExEnv")), pos = "CheckExEnv")
base::cat("eigenmap", base::get(".format_ptime", pos = 'CheckExEnv')(get(".dptime", pos = "CheckExEnv")), "\n", file=base::get(".ExTimings", pos = 'CheckExEnv'), append=TRUE, sep="\t")
cleanEx()
nameEx("geodesics")
### * geodesics

flush(stderr()); flush(stdout())

base::assign(".ptime", proc.time(), pos = "CheckExEnv")
### Name: geodesics
### Title: Calculation of Geodesic Distances
### Aliases: geodesics

### ** Examples

##
### First example: locations spread throughout the world
##
coords <- cbind(c(43,22,9,12,-40,72,-86,-22),
                c(-135,22,0,1,-45,12,27,-139))
res_hav <- geodesics(coords)  ## Default: the haversine formula
res_hav
res_vif <- geodesics(coords,method = "Vincenty")
res_vif
attr(res_vif,"niter") ## The numbers of iterations
res_vif-res_hav       ## Absolute difference
200*(res_vif-res_hav)/(res_vif+res_hav) ## Large relative difference
##
### Second example: locations nearer from one another
##
coords <- cbind(c(45.01,44.82,45.23,44.74),
                c(72.03,72.34,71.89,72.45))
res_hav <- geodesics(coords)
res_vif <- geodesics(coords,method = "Vincenty")
res_vif-res_hav       ## Absolute difference
200*(res_vif-res_hav)/(res_vif+res_hav) ## Relative difference are smaller
##




base::assign(".dptime", (proc.time() - get(".ptime", pos = "CheckExEnv")), pos = "CheckExEnv")
base::cat("geodesics", base::get(".format_ptime", pos = 'CheckExEnv')(get(".dptime", pos = "CheckExEnv")), "\n", file=base::get(".ExTimings", pos = 'CheckExEnv'), append=TRUE, sep="\t")
cleanEx()
nameEx("mca")
### * mca

flush(stderr()); flush(stdout())

base::assign(".ptime", proc.time(), pos = "CheckExEnv")
### Name: mca
### Title: Multiple-descriptors, Multiscale Codependence Analysis
### Aliases: mca MCA test.cdp permute.cdp parPermute.cdp

### ** Examples

### Example 1: St. Marguerite River Salmon Transect
data(salmon)

## Converting the data from data frames to to matrices:
Abundance <- log1p(as.matrix(salmon[,"Abundance",drop=FALSE]))
Environ <- as.matrix(salmon[,3L:5])

## Creating a spatial eigenvector map:
map1 <- eigenmap(x=salmon[,"Position"],weighting=wf.binary,boundaries=c(0,20))

## Case of a single descriptor:
mca1 <- MCA(Y=Abundance,X=Environ[,"Substrate",drop=FALSE],emobj=map1)
mca1
mca1_partest <- test.cdp(mca1)
mca1_partest
summary(mca1_partest)
par(mar = c(6,4,2,4))
plot(mca1_partest, las = 3)
mca1_pertest <- permute.cdp(mca1)
## Not run: 
##D ## or:
##D mca1_pertest <- parPermute.cdp(mca1,permute=999999)
## End(Not run)
mca1_pertest
summary(mca1_pertest)
plot(mca1_pertest, las = 3)
mca1_pertest$UpYXcb$C # Array containing the codependence coefficients

## With all descriptors at once:
mca2 <- MCA(Y=log1p(as.matrix(salmon[,"Abundance",drop=FALSE])),
            X=as.matrix(salmon[,3L:5]),emobj=map1)
mca2
mca2_partest <- test.cdp(mca2)
mca2_partest
summary(mca2_partest)
par(mar = c(6,4,2,4))
plot(mca2_partest, las = 3)
mca2_pertest <- permute.cdp(mca2)
## Not run: 
##D ## or:
##D     mca2_pertest <- parPermute.cdp(mca2,permute=999999)
## End(Not run)
mca2_pertest
summary(mca2_pertest)
plot(mca2_pertest, las = 3)
mca2_pertest$UpYXcb$C # Array containing the codependence coefficients
mca2_pertest$UpYXcb$C[,1L,] # now turned into a matrix.

### Example 2: Doubs Fish Community Transect

data(Doubs)

## Creating a spatial eigenvector map:
map2 <- eigenmap(x=Doubs.geo[,"DFS"])

mca3 <- MCA(Y=log1p(Doubs.fish),X=Doubs.env,emobj=map2)
mca3
mca3_pertest <- permute.cdp(mca3)
## Not run: 
##D   ## or:
##D   mca3_pertest <- parPermute.cdp(mca3,permute=999999)
## End(Not run)
mca3_pertest
summary(mca3_pertest)
par(mar = c(6,4,2,4))
plot(mca3_pertest, las = 2)
mca3_pertest$UpYXcb$C # Array containing the codependence coefficients

## Display the results along the transect
spmeans <- colMeans(log1p(Doubs.fish))
pca1 <- svd(log1p(Doubs.fish) - rep(spmeans,each=nrow(Doubs.fish)))
par(mar = c(5,5,2,5)+0.1)
plot(y = pca1$u[,1L], x = Doubs.geo[,"DFS"], pch = 21L, bg = "red",
     ylab = "PCA1 loadings", xlab = "Distance from river source (km)")

x <- seq(0,450,1)
newdists <- matrix(NA, length(x), nrow(Doubs.geo))
for(i in 1L:nrow(newdists))
  newdists[i,] <- abs(Doubs.geo[,"DFS"] - x[i])

## Calculating predictions for arbitrary sites under the same set of
## environmental conditions that the codependence model was built with.
prd1 <- predict(mca3_pertest,
                newdata=list(target = eigenmap.score(map2, newdists)))

## Projection of the predicted species abundance on pca1:
Uprd1 <-
  (prd1 - rep(spmeans, each = nrow(prd1))) %*%
  pca1$v %*% diag(pca1$d^-1)
lines(y = Uprd1[,1L], x = x, col=2, lty = 1)

## Projection of the predicted species abundance on pca2:
plot(y = pca1$u[,2L], x = Doubs.geo[,"DFS"], pch = 21L, bg = "red",
     ylab = "PCA2 loadings", xlab = "Distance from river source (km)")
lines(y = Uprd1[,2L], x = x, col=2, lty = 1)

## Displaying only the observed and predicted abundance for Brown Trout.
par(new=TRUE)
plot(y = log1p(Doubs.fish[,"TRU"]),Doubs.geo[,"DFS"],pch=21L,bg="green",
     ylab="",xlab="",new=FALSE,axes=FALSE)
axis(4)
lines(y = prd1[,"TRU"], x = x, col=3)
mtext(side=4, "log(Abundance+1)", line = 2.5)

### Example 3: Borcard et al. Oribatid Mite

data(mite)

map3 <- eigenmap(x = mite.geo)
## Organize the environmental variables
mca4 <- MCA(Y = log1p(mite.species), X = mite.env, emobj = map3)
mca4_partest <- test.cdp(mca4, response.tests = FALSE)
summary(mca4_partest)
plot(mca4_partest, las = 2, lwd = 2)
plot(mca4_partest, col = rainbow(1200)[1L:1000], las = 3, lwd = 4,
     main = "Codependence diagram", col.signif = "white")

rng <- list(x = seq(min(mite.geo[,"x"]) - 0.1, max(mite.geo[,"x"]) + 0.1, 0.05),
            y = seq(min(mite.geo[,"y"]) - 0.1, max(mite.geo[,"y"]) + 0.1, 0.05))
grid <- cbind(x = rep(rng[["x"]], length(rng[["y"]])),
              y = rep(rng[["y"]], each = length(rng[["x"]])))
newdists <- matrix(NA, nrow(grid), nrow(mite.geo))
for(i in 1L:nrow(grid)) {
  newdists[i,] <- ((mite.geo[,"x"] - grid[i,"x"])^2 +
                     (mite.geo[,"y"] - grid[i,"y"])^2)^0.5
}

spmeans <- colMeans(mite.species)
pca2 <- svd(log1p(mite.species) - rep(spmeans, each = nrow(mite.species)))

prd2 <- predict(mca4_partest,
                newdata = list(target = eigenmap.score(map3, newdists)))
Uprd2 <-
(prd2 - rep(spmeans, each = nrow(prd2))) %*%
pca2$v %*% diag(pca2$d^-1)

## Printing the response variable
prmat <- Uprd2[,1L]
dim(prmat) <- c(length(rng$x),length(rng$y))
zlim <- c(min(min(prmat),min(pca2$u[,1L])),max(max(prmat),max(pca2$u[,1L])))
image(z = prmat, x = rng$x, y = rng$y, asp = 1, zlim = zlim,
      col = rainbow(1200L)[1L:1000], ylab = "y", xlab = "x")
points(
  x=mite.geo[,"x"], y=mite.geo[,"y"], pch=21L,
  bg = rainbow(1200L)[round(1+(999*(pca2$u[,1L]-zlim[1L])/(zlim[2L]-zlim[1L])),0)])




base::assign(".dptime", (proc.time() - get(".ptime", pos = "CheckExEnv")), pos = "CheckExEnv")
base::cat("mca", base::get(".format_ptime", pos = 'CheckExEnv')(get(".dptime", pos = "CheckExEnv")), "\n", file=base::get(".ExTimings", pos = 'CheckExEnv'), append=TRUE, sep="\t")
graphics::par(get("par.postscript", pos = 'CheckExEnv'))
cleanEx()
nameEx("minpermute")
### * minpermute

flush(stderr()); flush(stdout())

base::assign(".ptime", proc.time(), pos = "CheckExEnv")
### Name: minpermute
### Title: Number of Permutations for MCA
### Aliases: minpermute

### ** Examples

## For a 5% threshold under 50 tests.
minpermute(alpha = 0.05, nbtest=50)

## Allowing more margin (implies more computation time).
minpermute(alpha = 0.05, nbtest=50, margin=10, ru=3)




base::assign(".dptime", (proc.time() - get(".ptime", pos = "CheckExEnv")), pos = "CheckExEnv")
base::cat("minpermute", base::get(".format_ptime", pos = 'CheckExEnv')(get(".dptime", pos = "CheckExEnv")), "\n", file=base::get(".ExTimings", pos = 'CheckExEnv'), append=TRUE, sep="\t")
cleanEx()
nameEx("mite")
### * mite

flush(stderr()); flush(stdout())

base::assign(".ptime", proc.time(), pos = "CheckExEnv")
### Name: mite
### Title: The Oribatid Mite Data Set
### Aliases: mite mite.species mite.env mite.geo
### Keywords: mite

### ** Examples

data(mite)
summary(mite.species)
summary(mite.env)
summary(mite.geo)




base::assign(".dptime", (proc.time() - get(".ptime", pos = "CheckExEnv")), pos = "CheckExEnv")
base::cat("mite", base::get(".format_ptime", pos = 'CheckExEnv')(get(".dptime", pos = "CheckExEnv")), "\n", file=base::get(".ExTimings", pos = 'CheckExEnv'), append=TRUE, sep="\t")
cleanEx()
nameEx("product-distribution")
### * product-distribution

flush(stderr()); flush(stdout())

base::assign(".ptime", proc.time(), pos = "CheckExEnv")
### Name: product-distribution
### Title: Frequency Distributions for MCA Parametric Testing
### Aliases: product-distribution dphi pphi dtau ptau

### ** Examples

### Displays the phi probability distribution for five different numbers
### of degrees of freedom:
x <- 10^seq(-4, 0.5, 0.05)
plot(y = dphi(x, 1, 10), x = x, type = "l", col = "black", las = 1,
ylab = "pdf", ylim = c(0, 0.5))
lines(y = dphi(x, 3, 10), x = x, col = "purple")
lines(y = dphi(x, 5, 70), x = x, col = "blue")
lines(y = dphi(x, 12, 23), x = x, col = "green")
lines(y = dphi(x, 35, 140), x = x, col = "red")

### Displays the density distribution function for 10 degrees of freedom
### and the cumulative probability above x = 1.
x <- 10^seq(-4, 0.5, 0.05)
y <- dphi(x, 5, 70)
plot(y = y, x = x, type = "l", col = "black", las = 1, ylab = "Density",
     ylim = c(0, 0.5))
polygon(x = c(x[81L:91], x[length(x)], 1), y = c(y[81L:91], 0, 0),
        col = "grey")
text(round(pphi(1, 5, 70, lower.tail=FALSE), 3), x = 1.75, y = 0.05)

## Idem for the tau distribution:
x <- c(-(10^seq(0.5, -4, -0.05)), 10^seq(-4, 0.5, 0.05))
plot(y = dtau(x, 1), x = x, type = "l", col = "black", las = 1,
     ylab = "pdf", ylim = c(0, 0.5))
lines(y = dtau(x, 2), x = x, col = "purple")
lines(y = dtau(x, 5), x = x, col="blue")
lines(y = dtau(x, 10), x = x, col="green")
lines(y = dtau(x, 100), x = x, col="red")

y <- dtau(x, 10)
plot(y = y, x = x, type = "l", col = "black", las = 1, ylab = "Density",
     ylim = c(0, 0.5))
polygon(x = c(x[which(x==1):length(x)], x[length(x)],1),
        y = c(y[which(x==1):length(x)], 0, 0), col = "grey")
text(round(ptau(1, 10, lower.tail = FALSE), 3), x = 1.5, y = 0.03)
polygon(x = c(-1, x[1L], x[1L:which(x==-1)]),
        y = c(0, 0, y[1L:which(x==-1)]), col="grey")
text(round(ptau(-1, 10), 3), x = -1.5, y = 0.03)




base::assign(".dptime", (proc.time() - get(".ptime", pos = "CheckExEnv")), pos = "CheckExEnv")
base::cat("product-distribution", base::get(".format_ptime", pos = 'CheckExEnv')(get(".dptime", pos = "CheckExEnv")), "\n", file=base::get(".ExTimings", pos = 'CheckExEnv'), append=TRUE, sep="\t")
cleanEx()
nameEx("salmon")
### * salmon

flush(stderr()); flush(stdout())

base::assign(".ptime", proc.time(), pos = "CheckExEnv")
### Name: salmon
### Title: The St. Marguerite River Altantic Salmon Parr Transect
### Aliases: salmon
### Keywords: salmon

### ** Examples

data(salmon)
summary(salmon)




base::assign(".dptime", (proc.time() - get(".ptime", pos = "CheckExEnv")), pos = "CheckExEnv")
base::cat("salmon", base::get(".format_ptime", pos = 'CheckExEnv')(get(".dptime", pos = "CheckExEnv")), "\n", file=base::get(".ExTimings", pos = 'CheckExEnv'), append=TRUE, sep="\t")
cleanEx()
nameEx("weighting-functions")
### * weighting-functions

flush(stderr()); flush(stdout())

base::assign(".ptime", proc.time(), pos = "CheckExEnv")
### Name: weighting-functions
### Title: Weighting Functions for Spatial Eigenvector Map
### Aliases: weighting-functions wf.sqrd wf.RBF wf.PCNM wf.binary wf.Drayf1
###   wf.Drayf2 wf.Drayf3

### ** Examples

locations <- c(1,2,4,7,10,14,17,21)
D <- dist(locations)
wf.sqrd(D)
wf.RBF(D, wpar = 0.1)
wf.binary(D, c(0,5))
wf.PCNM(D, c(0,5))
wf.Drayf1(D, c(0,5))
wf.Drayf2(D, c(0,5), 0.5)
wf.Drayf3(D, c(0,5), 0.5)

emap <- eigenmap(D, locations, wf.Drayf2, c(0,5), 0.5)
emap

emap <- eigenmap(D, locations, wf.Drayf3, c(0,5), 0.25)
emap

emap <- eigenmap(D, locations, wf.RBF, wpar = 0.1)
emap




base::assign(".dptime", (proc.time() - get(".ptime", pos = "CheckExEnv")), pos = "CheckExEnv")
base::cat("weighting-functions", base::get(".format_ptime", pos = 'CheckExEnv')(get(".dptime", pos = "CheckExEnv")), "\n", file=base::get(".ExTimings", pos = 'CheckExEnv'), append=TRUE, sep="\t")
### * <FOOTER>
###
cleanEx()
options(digits = 7L)
base::cat("Time elapsed: ", proc.time() - base::get("ptime", pos = 'CheckExEnv'),"\n")
grDevices::dev.off()
###
### Local variables: ***
### mode: outline-minor ***
### outline-regexp: "\\(> \\)?### [*]+" ***
### End: ***
quit('no')
